
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Flame, Heart, Headphones, Globe, Palette, Bell, Bookmark, Download, Settings } from 'lucide-react';
import { MOCK_MANGAS, LANGUAGES } from '../constants';
import { Manga, User as UserType, Language } from '../types';
import { useSound } from '../hooks/useSound';

interface Props {
  user: UserType;
  onMangaSelect: (manga: Manga) => void;
  onProfileClick: () => void;
  onLanguageChange: (lang: Language) => void;
  currentLanguage: Language;
}

const HomeScreen: React.FC<Props> = ({ user, onMangaSelect, onProfileClick, onLanguageChange, currentLanguage }) => {
  const { playSound } = useSound(user.soundEnabled);
  const [showLangSheet, setShowLangSheet] = useState(false);
  const trending = MOCK_MANGAS.filter(m => m.trending);
  const normal = MOCK_MANGAS;

  const handleMangaTap = (manga: Manga) => {
    playSound('CLICK');
    onMangaSelect(manga);
  };

  return (
    <div className="h-full overflow-y-auto pb-48 px-6 pt-10 bg-gradient-to-b from-[#0a0a25] via-[#050505] to-[#050505] relative scroll-smooth">
      {/* Header */}
      <div className="flex items-center justify-between mb-10">
        <div>
          <h2 className="text-blue-500 text-[10px] font-black uppercase tracking-[0.3em] mb-1">Elite Portal</h2>
          <h1 className="text-4xl font-black neon-glow flex items-center gap-3 tracking-tighter">
            Aura, {user.name}
          </h1>
        </div>
        <div className="flex gap-4">
          <motion.button 
            whileHover={{ scale: 1.1, rotate: 5 }}
            whileTap={{ scale: 0.9 }}
            className="w-14 h-14 rounded-[22px] glass flex items-center justify-center text-blue-400 border border-blue-500/20 shadow-[0_0_20px_rgba(59,130,246,0.15)]"
          >
            <Bell size={24} />
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.1, rotate: -5 }}
            whileTap={{ scale: 0.9 }}
            onClick={onProfileClick}
            className="w-14 h-14 rounded-[22px] overflow-hidden border-2 border-purple-500 shadow-[0_0_25px_rgba(168,85,247,0.3)] p-0.5 bg-black"
          >
            <img src={user.avatar} alt="Profile" className="w-full h-full object-cover rounded-[18px]" />
          </motion.button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative mb-12 group">
        <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center gap-3">
          <Search className="text-gray-500 group-focus-within:text-blue-400 transition-colors" size={24} />
          <div className="w-[2px] h-6 bg-white/5" />
        </div>
        <input 
          type="text" 
          placeholder="Search Neon Blade or Originals..." 
          className="w-full h-20 pl-20 pr-8 rounded-[32px] glass text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all border border-white/10 focus:border-blue-500/50 text-lg font-bold"
        />
      </div>

      {/* Trending Section */}
      <section className="mb-14">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-3xl font-black flex items-center gap-4 tracking-tight">
            <div className="p-2 bg-orange-500/20 rounded-xl"><Flame className="text-orange-500" size={28} fill="currentColor" /></div>
            Trending Now
          </h3>
          <button className="text-blue-400 text-xs font-black tracking-widest uppercase hover:underline">Full Feed</button>
        </div>
        <div className="flex gap-8 overflow-x-auto pb-10 scrollbar-hide snap-x px-2">
          {trending.map((m, i) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ delay: i * 0.15 }}
              whileHover={{ y: -15, scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleMangaTap(m)}
              className="relative min-w-[320px] h-[480px] rounded-[50px] overflow-hidden snap-start cursor-pointer group shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)] border border-white/10"
            >
              <img src={m.cover} className="w-full h-full object-cover transform transition-transform duration-1000 group-hover:scale-110" alt={m.title} />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
              
              <div className="absolute bottom-0 left-0 p-10 w-full">
                <div className="flex gap-3 mb-5">
                  {m.tags.map(t => (
                    <span key={t} className="px-4 py-1.5 rounded-full bg-blue-600/20 backdrop-blur-xl border border-blue-500/30 text-[10px] font-black uppercase tracking-widest text-blue-300">{t}</span>
                  ))}
                </div>
                <h4 className="text-4xl font-black mb-3 group-hover:text-blue-400 transition-colors leading-none tracking-tighter">{m.title}</h4>
                <p className="text-gray-400 text-sm line-clamp-2 leading-relaxed font-medium">{m.description}</p>
              </div>

              {m.isPremium && (
                <div className="absolute top-8 right-8 px-5 py-2 rounded-2xl bg-gradient-to-r from-yellow-400 to-orange-500 text-[10px] font-black uppercase text-black shadow-[0_10px_30px_rgba(234,179,8,0.4)]">
                  Premium
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      {/* Discovery Grid */}
      <section className="px-2">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-2xl font-black tracking-tight">Recent Archives</h3>
          <button className="text-purple-400 text-xs font-black uppercase tracking-widest">Library</button>
        </div>
        <div className="grid grid-cols-2 gap-8">
          {normal.map((m, i) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleMangaTap(m)}
              className="relative rounded-[40px] overflow-hidden glass p-4 cursor-pointer border border-white/5 shadow-xl group"
            >
              <div className="relative aspect-[3/4] rounded-[30px] overflow-hidden mb-5">
                <img src={m.cover} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={m.title} />
                <div className="absolute bottom-4 right-4 px-4 py-2 rounded-2xl bg-black/80 backdrop-blur-xl text-[11px] font-black border border-white/10 text-blue-400">
                  CH. {m.chapters.length}
                </div>
              </div>
              <div className="px-2">
                <h4 className="font-black text-lg mb-1 truncate tracking-tight">{m.title}</h4>
                <p className="text-gray-500 text-xs font-bold truncate uppercase tracking-[0.2em]">{m.author}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* REPAIRED & MOVED UP FLOATING ACTION BAR */}
      <motion.div 
        initial={{ y: 150, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, type: 'spring', damping: 20 }}
        className="fixed bottom-14 left-8 right-8 z-50 pointer-events-none"
      >
        <div className="h-24 rounded-[40px] glass border border-white/20 flex items-center justify-around px-4 shadow-[0_30px_90px_-10px_rgba(0,0,0,1)] relative overflow-visible pointer-events-auto">
          {/* Subtle Glow Behind Bar */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-[40px] -z-10" />
          
          <FloatingBtn icon={<Palette size={28} />} label="Color" color="text-pink-400" onClick={() => playSound('CLICK')} />
          <FloatingBtn 
            icon={<Globe size={28} />} 
            label={currentLanguage.slice(0, 3)} 
            color="text-blue-400" 
            onClick={() => { playSound('CLICK'); setShowLangSheet(true); }} 
          />
          
          {/* Central Prominent Button */}
          <motion.div 
            whileHover={{ scale: 1.15, y: -10 }}
            whileTap={{ scale: 0.9 }}
            className="w-20 h-20 -mt-12 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-[0_15px_40px_rgba(37,99,235,0.6)] border-[6px] border-[#050505] cursor-pointer"
          >
            <Flame size={32} className="text-white drop-shadow-lg" fill="currentColor" />
          </motion.div>

          <FloatingBtn icon={<Download size={28} />} label="Save" color="text-cyan-400" onClick={() => playSound('REWARD')} />
          <FloatingBtn icon={<Heart size={28} />} label="Favs" color="text-red-400" onClick={() => playSound('CLICK')} />
        </div>
      </motion.div>

      {/* Language Bottom Sheet */}
      <AnimatePresence>
        {showLangSheet && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLangSheet(false)}
              className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-[101] rounded-t-[60px] bg-[#0a0a0a] p-12 border-t border-white/10 shadow-[0_-20px_100px_rgba(0,0,0,1)]"
            >
              <div className="w-20 h-2 bg-white/20 rounded-full mx-auto mb-12" />
              <h2 className="text-4xl font-black mb-10 text-center neon-glow tracking-tighter italic">Switch Dimension</h2>
              <div className="grid grid-cols-3 gap-5">
                {LANGUAGES.map(lang => (
                  <motion.button
                    key={lang}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      onLanguageChange(lang);
                      setShowLangSheet(false);
                      playSound('SPARKLE');
                    }}
                    className={`h-20 rounded-[30px] border-2 flex flex-col items-center justify-center font-black transition-all ${
                      currentLanguage === lang 
                        ? 'border-blue-500 bg-blue-500/20 text-blue-400 shadow-[0_0_30px_rgba(59,130,246,0.4)]' 
                        : 'border-white/5 bg-white/5 text-gray-500 hover:border-white/20'
                    }`}
                  >
                    <span className="text-sm tracking-wider">{lang}</span>
                  </motion.button>
                ))}
              </div>
              <div className="mt-10 h-10" />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

const FloatingBtn = ({ icon, label, onClick, color }: { icon: React.ReactNode, label: string, onClick: () => void, color: string }) => (
  <motion.button 
    whileHover={{ scale: 1.1, y: -5 }}
    whileTap={{ scale: 0.8, rotate: 10 }}
    onClick={onClick}
    className="flex flex-col items-center gap-2 group relative py-2"
  >
    <div className={`${color} group-hover:drop-shadow-[0_0_10px_currentColor] transition-all`}>
      {icon}
    </div>
    <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest group-hover:text-white transition-colors">{label}</span>
    <motion.div className="absolute -inset-2 bg-white/0 group-active:bg-white/5 rounded-3xl -z-10" />
  </motion.button>
);

export default HomeScreen;
