
import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const geminiService = {
  async translateManga(text: string, targetLanguage: string) {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Translate the following manga dialogue into ${targetLanguage}. Keep the tone authentic to the genre: "${text}"`,
    });
    return response.text || text;
  },

  async summarizeChapter(chapterTitle: string, context: string) {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a quick 2-minute summary of the manga chapter "${chapterTitle}" based on this context: ${context}`,
    });
    return response.text;
  },

  async explainScene(context: string) {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explain what is happening in this manga scene in simple terms: ${context}`,
    });
    return response.text;
  },

  async generateNarration(text: string, emotion: string = 'Epic') {
    // Note: In a real app, you'd handle AudioContext here as per guidelines
    // For this prototype, we'll return a promise that mimics the TTS response structure
    const prompt = `Say in a ${emotion} tone: ${text}`;
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });
      return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    } catch (error) {
      console.error("TTS Error", error);
      return null;
    }
  }
};
