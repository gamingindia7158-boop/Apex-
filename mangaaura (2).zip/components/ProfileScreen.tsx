
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Coins, Trophy, Clock, Star, Download, ChevronRight, Volume2, VolumeX, Shield, BellRing, LogOut, Sparkles } from 'lucide-react';
import { User } from '../types';
import { useSound } from '../hooks/useSound';

interface Props {
  user: User;
  onBack: () => void;
  onToggleSound: () => void;
}

const ProfileScreen: React.FC<Props> = ({ user, onBack, onToggleSound }) => {
  const { playSound } = useSound(user.soundEnabled);

  return (
    <div className="h-full bg-gradient-to-b from-[#181035] via-[#050505] to-[#050505] overflow-y-auto pb-48 px-10 pt-20 relative">
      {/* Top Nav */}
      <div className="flex items-center gap-8 mb-16">
        <motion.button 
          whileHover={{ scale: 1.1, rotate: 10 }}
          whileTap={{ scale: 0.8 }}
          onClick={onBack} 
          className="w-16 h-16 rounded-3xl glass flex items-center justify-center border border-white/10"
        >
          <ChevronLeft size={32} />
        </motion.button>
        <h1 className="text-3xl font-black tracking-tighter">Aura Nexus</h1>
      </div>

      {/* Profile Header */}
      <div className="flex flex-col items-center mb-16">
        <div className="relative mb-8">
          <motion.div 
            initial={{ scale: 0.7, opacity: 0, rotate: -20 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            className="w-48 h-48 rounded-[60px] p-2 bg-gradient-to-tr from-purple-600 via-blue-600 to-pink-500 shadow-[0_0_60px_rgba(168,85,247,0.5)] rotate-3"
          >
            <img src={user.avatar} className="w-full h-full rounded-[50px] border-[10px] border-[#050505] object-cover" alt="Avatar" />
          </motion.div>
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 4 }}
            className="absolute -bottom-4 left-1/2 -translate-x-1/2 px-8 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 text-[12px] font-black shadow-2xl border border-white/20 whitespace-nowrap tracking-widest"
          >
            AURAMASTER LVL 99
          </motion.div>
        </div>
        <h2 className="text-5xl font-black mb-2 neon-glow tracking-tighter italic">{user.name}</h2>
        <p className="text-blue-400 font-black uppercase tracking-[0.4em] text-[10px]">Prime Subscriber • Zone 7</p>
      </div>

      {/* Rewards Ticker */}
      <div className="mb-12 overflow-hidden glass rounded-3xl py-4 flex gap-8">
        <motion.div 
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="flex gap-8 whitespace-nowrap items-center text-[10px] font-black uppercase tracking-widest text-purple-400"
        >
          <span>Claim Daily Login 50 Coins</span>
          <Sparkles size={14} />
          <span>New Episode Released: Neon Blade Ch. 2</span>
          <Sparkles size={14} />
          <span>Reward: +10 XP earned from reading</span>
          <Sparkles size={14} />
        </motion.div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-8 mb-12">
        <StatCard 
          icon={<Coins className="text-yellow-400" size={36} />} 
          value={user.coins.toLocaleString()} 
          label="Nexus Credits" 
          color="border-yellow-500/20"
        />
        <StatCard 
          icon={<Trophy className="text-pink-500" size={36} />} 
          value={`${user.streak} Days`} 
          label="Portal Streak" 
          color="border-pink-500/20"
        />
      </div>

      {/* Settings Grid */}
      <div className="space-y-6 mb-16">
        <h4 className="text-[12px] font-black text-gray-500 uppercase tracking-[0.4em] ml-6 mb-4 italic">Neural Settings</h4>
        <div className="space-y-4">
          <SettingsToggle 
            icon={user.soundEnabled ? <Volume2 size={28} /> : <VolumeX size={28} />} 
            label="Synapse SFX" 
            active={user.soundEnabled} 
            onToggle={() => { onToggleSound(); }} 
          />
          <SettingsItem icon={<Shield size={28} />} label="Security Protocol" active />
          <SettingsItem icon={<BellRing size={28} />} label="Priority Uplinks" />
          <SettingsItem icon={<Star size={28} />} label="Aura Favorites" detail="12 Archived" />
          <SettingsItem icon={<LogOut size={28} />} label="Disconnect Portal" danger />
        </div>
      </div>

      {/* Premium CTA */}
      <motion.button 
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.95 }}
        className="w-full p-1 rounded-[40px] bg-gradient-to-r from-blue-600 via-purple-600 to-pink-500 shadow-2xl mb-12"
      >
        <div className="w-full h-full bg-black/90 backdrop-blur-xl rounded-[38px] p-8 flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-black mb-1">Upgrade Aura</h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Unlock 4K AI Color Mode</p>
          </div>
          <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-white/10">
            <Sparkles className="text-yellow-400" size={28} />
          </div>
        </div>
      </motion.button>
    </div>
  );
};

const StatCard = ({ icon, value, label, color }: { icon: React.ReactNode, value: string, label: string, color: string }) => (
  <div className={`glass p-10 rounded-[45px] border-b-8 ${color} relative overflow-hidden group shadow-2xl`}>
    <div className="mb-8 bg-white/5 w-18 h-18 rounded-[25px] flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform">
      {icon}
    </div>
    <div className="text-4xl font-black mb-2 tracking-tighter">{value}</div>
    <div className="text-[10px] text-gray-500 uppercase font-black tracking-widest italic">{label}</div>
    <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-3xl -z-10 group-hover:bg-white/10 transition-colors" />
  </div>
);

const SettingsToggle = ({ icon, label, active, onToggle }: { icon: React.ReactNode, label: string, active: boolean, onToggle: () => void }) => (
  <button 
    onClick={onToggle}
    className="w-full glass h-22 px-8 rounded-[35px] flex items-center justify-between border-2 border-white/5 hover:border-white/20 transition-all shadow-xl"
  >
    <div className="flex items-center gap-6">
      <div className={`${active ? 'text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.6)]' : 'text-gray-600'}`}>{icon}</div>
      <span className="font-black text-lg tracking-tight">{label}</span>
    </div>
    <div className={`w-16 h-8 rounded-full p-1.5 transition-all duration-500 ${active ? 'bg-blue-600 shadow-[0_0_20px_rgba(37,99,235,0.4)]' : 'bg-white/10'}`}>
      <motion.div 
        animate={{ x: active ? 32 : 0 }}
        className="w-5 h-5 bg-white rounded-full shadow-lg" 
      />
    </div>
  </button>
);

const SettingsItem = ({ icon, label, detail, active, danger }: { icon: React.ReactNode, label: string, detail?: string, active?: boolean, danger?: boolean }) => (
  <button className={`w-full glass h-22 px-8 rounded-[35px] flex items-center justify-between group border-2 border-white/5 hover:border-white/20 transition-all shadow-xl ${danger ? 'text-red-500' : ''}`}>
    <div className="flex items-center gap-6">
      <div className={`${active ? 'text-purple-400' : 'text-gray-500'} group-hover:scale-110 transition-transform`}>{icon}</div>
      <span className="font-black text-lg tracking-tight">{label}</span>
    </div>
    <div className="flex items-center gap-5">
      {detail && <span className="text-[11px] font-black text-gray-600 uppercase tracking-widest">{detail}</span>}
      {active && <div className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />}
      <ChevronRight size={24} className="text-gray-700 group-hover:text-white transition-colors" />
    </div>
  </button>
);

export default ProfileScreen;
