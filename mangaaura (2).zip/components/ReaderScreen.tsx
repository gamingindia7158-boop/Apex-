
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, MoreVertical, Maximize2, Palette, Mic, Zap, BookOpen, Volume2, Settings2, Play, Pause, Headphones, Share2, Heart, MicOff } from 'lucide-react';
import { Manga, Language, Emotion, User } from '../types';
import { useSound } from '../hooks/useSound';
import { geminiService } from '../services/gemini';

interface Props {
  manga: Manga;
  onClose: () => void;
  language: Language;
  user: User;
}

const ReaderScreen: React.FC<Props> = ({ manga, onClose, language, user }) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [isColorMode, setIsColorMode] = useState(false);
  const [isAutoScroll, setIsAutoScroll] = useState(false);
  const [isAIVoiceActive, setIsAIVoiceActive] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [emotion, setEmotion] = useState<Emotion>('Epic');
  const [activeDialogue, setActiveDialogue] = useState<{ speaker: string, text: string } | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const { playSound } = useSound(user.soundEnabled);
  const scrollRef = useRef<HTMLDivElement>(null);

  const activeChapter = manga.chapters[0];

  // Auto-scroll effect
  useEffect(() => {
    let interval: any;
    if (isAutoScroll && scrollRef.current) {
      interval = setInterval(() => {
        scrollRef.current?.scrollBy({ top: 1.8, behavior: 'auto' });
      }, 25);
    }
    return () => clearInterval(interval);
  }, [isAutoScroll]);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const scrollTop = scrollRef.current.scrollTop;
    const scrollHeight = scrollRef.current.scrollHeight;
    const clientHeight = scrollRef.current.clientHeight;
    
    // Calculate page progress
    const totalHeight = scrollHeight - clientHeight;
    const progress = scrollTop / totalHeight;
    const pageIndex = Math.min(
      activeChapter.pages.length - 1,
      Math.floor(progress * activeChapter.pages.length)
    );

    if (pageIndex !== currentPage) {
      setCurrentPage(pageIndex);
      if (isAIVoiceActive) playCurrentPanelDialogue(pageIndex);
    }
  };

  const playCurrentPanelDialogue = (index: number) => {
    const dialogue = activeChapter.dialogues?.find(d => d.panelIndex === index);
    if (dialogue) {
      setActiveDialogue({ speaker: dialogue.speaker, text: dialogue.text });
      playSound('CHIME');
    } else {
      setActiveDialogue(null);
    }
  };

  const toggleColorMode = () => {
    setIsColorMode(!isColorMode);
    playSound('SPARKLE');
  };

  const handleAIExplain = async () => {
    playSound('CLICK');
    const dialogue = activeChapter.dialogues?.find(d => d.panelIndex === currentPage);
    const context = dialogue ? `Scene: ${dialogue.text}` : "A cinematic manga scene.";
    const result = await geminiService.explainScene(context);
    alert(`💡 NEON AI: ${result}`);
  };

  const toggleAIVoice = () => {
    setIsAIVoiceActive(!isAIVoiceActive);
    playSound('WHOOSH');
    if (!isAIVoiceActive) {
      playCurrentPanelDialogue(currentPage);
    } else {
      setActiveDialogue(null);
    }
  };

  return (
    <div className="h-full bg-black text-white relative overflow-hidden select-none">
      {/* Dynamic Aura Background */}
      <AnimatePresence>
        {isColorMode && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-0"
          >
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-900/40 via-purple-900/40 to-black blur-[120px]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reader Content */}
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className={`h-full overflow-y-auto scrollbar-hide flex flex-col items-center transition-all duration-1000 z-10 relative ${
          isColorMode ? 'saturate-[1.5] brightness-110 contrast-110' : 'grayscale brightness-90 contrast-125'
        }`}
        onClick={() => setShowControls(!showControls)}
      >
        {activeChapter.pages.map((page, idx) => (
          <motion.div 
            key={idx} 
            className="relative w-full max-w-2xl mb-4 group"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "0px 0px -100px 0px" }}
          >
            <img 
              src={page} 
              className={`w-full h-auto transition-all duration-1000 ${
                isColorMode ? 'shadow-[0_0_80px_rgba(59,130,246,0.2)] rounded-3xl' : 'border-y border-white/5'
              }`} 
              alt={`Manga Page ${idx + 1}`} 
            />
            
            {/* Real Dialogue Overlay */}
            {activeChapter.dialogues?.find(d => d.panelIndex === idx) && (
              <div className="absolute bottom-12 left-8 right-8 flex flex-col items-start gap-3">
                <motion.span 
                  className="px-4 py-1.5 bg-blue-600/30 backdrop-blur-2xl border border-blue-500/40 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] text-blue-200 shadow-xl"
                >
                  {activeChapter.dialogues?.find(d => d.panelIndex === idx)?.speaker}
                </motion.span>
                <motion.div 
                  className="p-6 bg-black/60 backdrop-blur-3xl rounded-[30px] border border-white/10 shadow-2xl"
                >
                  <p className="text-lg font-bold leading-relaxed tracking-tight text-white/95 italic">
                    {activeChapter.dialogues?.find(d => d.panelIndex === idx)?.text}
                  </p>
                </motion.div>
              </div>
            )}
          </motion.div>
        ))}
        {/* End Screen Spacer */}
        <div className="h-64 flex flex-col items-center justify-center w-full bg-gradient-to-t from-blue-900/20 to-transparent">
          <h2 className="text-4xl font-black italic tracking-tighter neon-glow mb-4">CLIFFHANGER</h2>
          <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">Stay Tuned for Chapter 2</p>
        </div>
      </div>

      {/* AI Narration Active Caption */}
      <AnimatePresence>
        {isAIVoiceActive && activeDialogue && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="fixed bottom-36 left-10 right-10 z-[60] p-8 glass border-2 border-pink-500/40 rounded-[40px] shadow-[0_30px_70px_rgba(0,0,0,0.9)]"
          >
            <div className="flex items-center gap-4 mb-3">
              <div className="p-2 bg-pink-500/20 rounded-xl animate-pulse"><Headphones size={20} className="text-pink-400" /></div>
              <span className="text-[10px] font-black uppercase text-pink-400 tracking-[0.3em]">AI AURA VOICE • {emotion}</span>
            </div>
            <p className="text-2xl font-black leading-tight italic tracking-tighter">"{activeDialogue.text}"</p>
            <div className="mt-4 h-1 bg-white/10 rounded-full overflow-hidden">
               <motion.div 
                  animate={{ width: ["0%", "100%"] }} 
                  transition={{ duration: 3, repeat: Infinity }} 
                  className="h-full bg-pink-500 shadow-[0_0_15px_#ec4899]" 
               />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* REPAIRED CONTROLS */}
      <AnimatePresence>
        {showControls && (
          <>
            {/* TOP BAR - RESTORED MIC TO TOP RIGHT */}
            <motion.div 
              initial={{ y: -100 }}
              animate={{ y: 0 }}
              exit={{ y: -100 }}
              className="absolute top-0 left-0 right-0 h-28 glass border-b border-white/10 flex items-center justify-between px-10 z-[70] pt-4"
            >
              <div className="flex items-center gap-6">
                <motion.button 
                  whileTap={{ scale: 0.8 }}
                  onClick={onClose} 
                  className="w-14 h-14 rounded-2xl glass flex items-center justify-center border border-white/10"
                >
                  <ChevronLeft size={28} />
                </motion.button>
                <div>
                  <h3 className="font-black text-2xl tracking-tighter leading-none mb-1 text-blue-400">{manga.title}</h3>
                  <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.25em]">
                    {activeChapter.title} • {currentPage + 1}/{activeChapter.pages.length}
                  </p>
                </div>
              </div>

              {/* RESTORED MIC & SUMMARY BUTTONS */}
              <div className="flex gap-4">
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9, rotate: -15 }}
                  onClick={toggleAIVoice}
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center border-2 transition-all ${
                    isAIVoiceActive 
                    ? 'bg-pink-500/20 border-pink-500 text-pink-400 shadow-[0_0_20px_rgba(236,72,153,0.4)]' 
                    : 'glass border-white/10 text-gray-400'
                  }`}
                >
                  {isAIVoiceActive ? <Mic size={28} /> : <MicOff size={28} />}
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={async () => {
                    playSound('REWARD');
                    const res = await geminiService.summarizeChapter(activeChapter.title, "Neon Blade Demo Content");
                    setSummary(res || "");
                  }}
                  className="w-14 h-14 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center border-2 border-blue-500/30"
                >
                  <Zap size={28} fill="currentColor" />
                </motion.button>
              </div>
            </motion.div>

            {/* SIDE TOOLBAR - MOVED UP TO THUMB REACH */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 100, opacity: 0 }}
              className="absolute right-8 top-1/2 -translate-y-1/2 flex flex-col gap-6 z-[70]"
            >
              <ReaderControlBtn 
                icon={<Palette size={32} className={isColorMode ? 'text-blue-400' : ''} />} 
                label="BURST" 
                active={isColorMode} 
                onClick={toggleColorMode} 
              />
              <ReaderControlBtn 
                icon={<BookOpen size={32} />} 
                label="INTEL" 
                onClick={handleAIExplain} 
              />
              <ReaderControlBtn 
                icon={isAutoScroll ? <Pause size={32} /> : <Play size={32} />} 
                label="FLOW" 
                active={isAutoScroll}
                onClick={() => { playSound('CLICK'); setIsAutoScroll(!isAutoScroll); }} 
              />
              <ReaderControlBtn 
                icon={<Share2 size={32} />} 
                label="LINK" 
                onClick={() => playSound('CLICK')} 
              />
            </motion.div>

            {/* BOTTOM EMOTION BAR - MOVED UP FOR THUMB REACH */}
            <motion.div 
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 100 }}
              className="absolute bottom-10 left-8 right-8 h-28 glass border border-white/10 rounded-[40px] flex items-center justify-between px-10 z-[70] shadow-2xl"
            >
              <div className="flex-1 flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {['Epic', 'Happy', 'Sad', 'Angry'].map((e) => (
                  <motion.button
                    key={e}
                    whileTap={{ scale: 0.85 }}
                    onClick={() => { playSound('CLICK'); setEmotion(e as Emotion); }}
                    className={`px-8 h-14 rounded-3xl text-xs font-black border-2 transition-all flex items-center justify-center uppercase tracking-widest ${
                      emotion === e 
                      ? 'bg-blue-500/20 border-blue-500 text-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.3)]' 
                      : 'bg-white/5 border-transparent text-gray-500 hover:border-white/20'
                    }`}
                  >
                    {e}
                  </motion.button>
                ))}
              </div>
              <div className="flex items-center gap-10 ml-10 border-l border-white/10 pl-10">
                <motion.button whileTap={{ scale: 0.7 }} className="text-gray-400 hover:text-white"><Settings2 size={30} /></motion.button>
                <motion.button whileTap={{ scale: 0.7 }} className="text-gray-400 hover:text-white"><Maximize2 size={30} /></motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* SUMMARY MODAL - REPAIRED VISUALS */}
      <AnimatePresence>
        {summary && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-10">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/95 backdrop-blur-[60px]" 
              onClick={() => setSummary(null)} 
            />
            <motion.div 
              initial={{ scale: 0.7, opacity: 0, rotateX: 20 }} animate={{ scale: 1, opacity: 1, rotateX: 0 }} exit={{ scale: 0.7, opacity: 0 }}
              className="relative glass p-12 rounded-[60px] max-w-xl w-full border-2 border-blue-500/30 shadow-[0_0_120px_rgba(59,130,246,0.3)]"
            >
              <div className="w-24 h-24 rounded-[30px] bg-blue-600/20 flex items-center justify-center mb-10 mx-auto border border-blue-500/30">
                <Zap size={48} className="text-blue-400 animate-pulse" fill="currentColor" />
              </div>
              <h2 className="text-4xl font-black mb-8 text-center neon-glow tracking-tighter italic">AI SYNAPSE CHAPTER SUMMARY</h2>
              <div className="max-h-[350px] overflow-y-auto pr-4 scrollbar-hide mb-10">
                <p className="text-gray-200 leading-relaxed italic text-xl text-center font-medium">"{summary}"</p>
              </div>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSummary(null)}
                className="w-full py-6 rounded-[30px] bg-blue-600 text-white font-black uppercase tracking-widest text-sm shadow-[0_15px_40px_rgba(37,99,235,0.4)]"
              >
                DISMISS TRANSMISSION
              </motion.button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const ReaderControlBtn = ({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) => (
  <motion.button
    whileHover={{ scale: 1.15, x: -10 }}
    whileTap={{ scale: 0.8 }}
    onClick={onClick}
    className={`w-20 h-20 rounded-[30px] glass flex flex-col items-center justify-center border-2 gap-1 transition-all ${
      active 
        ? 'border-white/60 bg-white/10 shadow-[0_0_30px_rgba(255,255,255,0.25)]' 
        : 'border-white/5 bg-white/5'
    }`}
  >
    {icon}
    <span className="text-[8px] font-black tracking-widest text-gray-400 uppercase">{label}</span>
  </motion.button>
);

export default ReaderScreen;
