
export interface Manga {
  id: string;
  title: string;
  author: string;
  cover: string;
  description: string;
  tags: string[];
  trending: boolean;
  isPremium: boolean;
  chapters: Chapter[];
}

export interface Chapter {
  id: number;
  title: string;
  pages: string[];
  dialogues?: { panelIndex: number; text: string; speaker: string; emotion?: Emotion }[];
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  coins: number;
  streak: number;
  favorites: string[];
  readChapters: number;
  soundEnabled: boolean;
}

export type Language = 
  | 'Hindi' 
  | 'Japanese' 
  | 'English' 
  | 'Bengali' 
  | 'Korean' 
  | 'Spanish' 
  | 'French' 
  | 'Arabic' 
  | 'Tamil';

export type ReadingMode = 'vertical' | 'horizontal';
export type Emotion = 'Sad' | 'Angry' | 'Happy' | 'Epic';
