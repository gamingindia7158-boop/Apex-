
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import SplashScreen from './components/SplashScreen';
import HomeScreen from './components/HomeScreen';
import ReaderScreen from './components/ReaderScreen';
import ProfileScreen from './components/ProfileScreen';
import { Manga, Language, User } from './types';
import { MOCK_USER } from './constants';
import { useSound } from './hooks/useSound';

const App: React.FC = () => {
  const [screen, setScreen] = useState<'splash' | 'home' | 'reader' | 'profile'>('splash');
  const [selectedManga, setSelectedManga] = useState<Manga | null>(null);
  const [language, setLanguage] = useState<Language>('English');
  const [user, setUser] = useState<User>(MOCK_USER);
  const { playSound } = useSound(user.soundEnabled);

  useEffect(() => {
    const timer = setTimeout(() => {
      setScreen('home');
      playSound('CHIME');
    }, 4500); 
    return () => clearTimeout(timer);
  }, [playSound]);

  const navigateToReader = (manga: Manga) => {
    playSound('WHOOSH');
    setSelectedManga(manga);
    setScreen('reader');
  };

  const navigateToHome = () => {
    playSound('WHOOSH');
    setScreen('home');
  };

  const navigateToProfile = () => {
    playSound('WHOOSH');
    setScreen('profile');
  };

  const toggleSound = () => {
    setUser(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }));
    playSound('CLICK');
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    playSound('REWARD');
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#050505]">
      <AnimatePresence mode="wait">
        {screen === 'splash' && (
          <SplashScreen key="splash" />
        )}

        {screen === 'home' && (
          <HomeScreen 
            key="home" 
            user={user} 
            onMangaSelect={navigateToReader} 
            onProfileClick={navigateToProfile}
            onLanguageChange={handleLanguageChange}
            currentLanguage={language}
          />
        )}

        {screen === 'reader' && selectedManga && (
          <ReaderScreen 
            key="reader" 
            manga={selectedManga} 
            onClose={navigateToHome}
            language={language}
            user={user}
          />
        )}

        {screen === 'profile' && (
          <ProfileScreen 
            key="profile" 
            user={user} 
            onBack={navigateToHome}
            onToggleSound={toggleSound}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
